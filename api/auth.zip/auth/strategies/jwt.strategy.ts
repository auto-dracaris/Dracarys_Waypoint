import { ExtractJwt, Strategy } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';
import { UserSessionRepository } from '../repositories/user-session.repository';
import { UserAuthRepository } from '../repositories/user-auth.repository';
import { UserStatus } from '../../users/enums/user.status.enum';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    private configService: ConfigService,
    private userSessionRepository: UserSessionRepository,
    private userAuthRepository: UserAuthRepository,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.getOrThrow<string>('JWT_SECRET'),
      passReqToCallback: true,
    });
  }

  async validate(req: Request & { tenantId?: string }, payload: any) {
    // Stateful on top of the signature/expiry check passport-jwt already did:
    // the session behind this token must still be live, scoped to the
    // tenant the request is calling as, and its owner must not have been
    // blocked/archived since the token was issued — otherwise a token stays
    // usable until its natural expiry no matter what happens to the account.
    const session = await this.userSessionRepository.findLiveById(payload.sid);
    if (!session || session.tenantId !== req.tenantId) {
      throw new UnauthorizedException('Session has been revoked');
    }

    const user = await this.userAuthRepository.findByTenantAndId(
      session.tenantId,
      session.userId,
    );
    if (
      !user ||
      user.status === UserStatus.BLOCKED ||
      user.status === UserStatus.DELETED
    ) {
      throw new UnauthorizedException('Session has been revoked');
    }

    return {
      userId: payload.userId,
      email: payload.email,
      roleId: payload.roleId,
      role: payload.role,
      sessionId: session.id,
    };
  }
}
