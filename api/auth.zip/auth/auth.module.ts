import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserDetail } from '../../database/entities/user.entity';
import { Role } from '../../database/entities/role.entity';
import { UserOtp } from '../../database/entities/user-otp.entity';
import { UserSession } from '../../database/entities/user-session.entity';
import { TenantsModule } from '../tenants/tenants.module';
import { SettingsModule } from '../settings/settings.module';
import { SmsService } from '../../common/services/sms.service';
import { UserAuthRepository } from './repositories/user-auth.repository';
import { RoleAuthRepository } from './repositories/role-auth.repository';
import { UserOtpRepository } from './repositories/user-otp.repository';
import { UserSessionRepository } from './repositories/user-session.repository';

import { JwtStrategy } from './strategies/jwt.strategy';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserDetail, Role, UserOtp, UserSession]),
    TenantsModule,
    SettingsModule,
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'),
        signOptions: {
          expiresIn: (configService.get<string>('JWT_EXPIRES_IN') ||
            '1d') as any,
        },
      }),
    }),
  ],
  providers: [
    AuthService,
    JwtStrategy,
    SmsService,
    UserAuthRepository,
    RoleAuthRepository,
    UserOtpRepository,
    UserSessionRepository,
  ],
  controllers: [AuthController],
  exports: [AuthService, UserSessionRepository],
})
export class AuthModule {}
