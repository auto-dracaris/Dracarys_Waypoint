import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DataSource, EntityManager } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import * as crypto from 'crypto';
import { formatPhoneNumber } from '../../common/utils/phone.util';
import { UserStatus } from '../users/enums/user.status.enum';
import { District } from '../users/enums/district.enum';
import { DEFAULT_AVATARS } from '../../common/constants/default-avatars.constant';
import * as bcrypt from 'bcrypt';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import { ApiResponseDto } from '../../common/dto/api-response.dto';
import { UserRole } from '../roles/enums/user-role.enum';
import { OtpPurpose } from './enums/otp-purpose.enum';
import { TenantsService } from '../tenants/tenants.service';
import { SmsService } from '../../common/services/sms.service';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { UpdateMeDto } from './dto/update-me.dto';
import { ResendOtpDto } from './dto/resend-otp.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { SmsTemplates } from '../../common/templates/sms.template';
import { UserAuthRepository } from './repositories/user-auth.repository';
import { RoleAuthRepository } from './repositories/role-auth.repository';
import { UserOtpRepository } from './repositories/user-otp.repository';
import { UserSessionRepository } from './repositories/user-session.repository';
import { UserSession } from '../../database/entities/user-session.entity';
import { SettingsService } from '../settings/settings.service';

const INVALID_OTP_MESSAGE = 'Invalid or expired OTP';

// RegisterDto leaves these optional (self-registration rarely collects them up front);
// `user_details` still requires them, so fall back to neutral placeholders the user can
// edit later via `PUT /api/auth/me`.
const DEFAULT_PROFILE_DEFAULTS = {
  birthday: '2000-01-01',
  address: 'Not specified',
  district: District.COLOMBO,
  city: 'Not specified',
};

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private usersRepository: UserAuthRepository,
    private rolesRepository: RoleAuthRepository,
    private userOtpRepository: UserOtpRepository,
    private userSessionRepository: UserSessionRepository,
    private tenantsService: TenantsService,
    private smsService: SmsService,
    private jwtService: JwtService,
    private dataSource: DataSource,
    private settingsService: SettingsService,
    private configService: ConfigService,
  ) {}

  private getRefreshTokenExpiry(): Date {
    const days = this.configService.get<number>(
      'REFRESH_TOKEN_EXPIRE_DAYS',
      30,
    );
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + days);
    return expiresAt;
  }

  /**
   * Creates a new live session for `userId` and returns both the signed
   * access token (carrying the session id as `sid`, so `JwtStrategy` can
   * verify the session is still live on every request) and a fresh opaque
   * refresh token, `"<sessionId>.<secret>"` — the id lets `refresh()` find
   * the row directly instead of scanning for a hash match; only a bcrypt
   * hash of `secret` is ever persisted.
   */
  private async issueSession(
    tenantId: string,
    userId: number,
    sessionType: UserSession['sessionType'],
    payload: { email: string; roleId: number; role?: string },
  ): Promise<{ accessToken: string; refreshToken: string }> {
    const session = this.userSessionRepository.create({
      tenantId,
      userId,
      sessionType,
      expiresAt: this.getRefreshTokenExpiry(),
    });
    const savedSession = await this.userSessionRepository.save(session);

    const secret = crypto.randomBytes(32).toString('hex');
    savedSession.refreshTokenHash = await bcrypt.hash(secret, 10);
    await this.userSessionRepository.save(savedSession);

    const accessToken = await this.jwtService.signAsync({
      ...payload,
      userId,
      sid: savedSession.id,
    });

    return { accessToken, refreshToken: `${savedSession.id}.${secret}` };
  }

  async login(loginDto: LoginDto, tenantId: string): Promise<ApiResponseDto> {
    const { phone, password: pass } = loginDto;

    const formattedPhone = formatPhoneNumber(phone);

    const user = await this.usersRepository.findByPhone(
      tenantId,
      formattedPhone,
      true,
    );

    if (!user || !(await bcrypt.compare(pass, user.password))) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const { accessToken, refreshToken } = await this.issueSession(
      tenantId,
      user.id,
      'login',
      {
        email: user.email,
        roleId: user.roleId,
        role: user.role?.name,
      },
    );

    const { password: _, ...result } = user;
    return new ApiResponseDto(HttpStatus.OK, 'Login successful', {
      ...result,
      accessToken,
      refreshToken,
    });
  }

  /** Rotates a refresh token: the presented one is revoked and a new session issued. */
  async refresh(
    dto: RefreshTokenDto,
    tenantId: string,
  ): Promise<ApiResponseDto> {
    const [sessionIdRaw, secret] = dto.refreshToken.split('.');
    const sessionId = Number(sessionIdRaw);

    if (!sessionId || !secret) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    const session = await this.userSessionRepository.findLiveById(sessionId);
    if (
      !session ||
      session.tenantId !== tenantId ||
      !session.refreshTokenHash ||
      !session.expiresAt ||
      session.expiresAt < new Date() ||
      !(await bcrypt.compare(secret, session.refreshTokenHash))
    ) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    const user = await this.usersRepository.findByTenantAndId(
      tenantId,
      session.userId,
      true,
    );
    if (
      !user ||
      user.status === UserStatus.BLOCKED ||
      user.status === UserStatus.DELETED
    ) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    // Revoke-then-issue: a replay of this same token can never rotate twice.
    await this.userSessionRepository.revokeById(session.id);
    const { accessToken, refreshToken } = await this.issueSession(
      tenantId,
      user.id,
      session.sessionType,
      {
        email: user.email,
        roleId: user.roleId,
        role: user.role?.name,
      },
    );

    return new ApiResponseDto(HttpStatus.OK, 'Token refreshed successfully', {
      accessToken,
      refreshToken,
    });
  }

  /** Revokes only the caller's own session — other devices stay logged in. */
  async logout(sessionId: number): Promise<ApiResponseDto> {
    await this.userSessionRepository.revokeById(sessionId);
    return new ApiResponseDto(HttpStatus.OK, 'Logged out successfully');
  }

  async changePassword(
    userId: number,
    tenantId: string,
    dto: ChangePasswordDto,
  ): Promise<ApiResponseDto> {
    const user = await this.usersRepository.findByTenantAndId(tenantId, userId);
    if (!user) {
      throw new UnauthorizedException('Current password is incorrect');
    }

    const isValid = await bcrypt.compare(dto.currentPassword, user.password);
    if (!isValid) {
      throw new UnauthorizedException('Current password is incorrect');
    }

    user.password = await bcrypt.hash(dto.newPassword, 10);
    await this.usersRepository.save(user);

    // Deliberately does NOT revoke the caller's own session — the point of
    // this endpoint is to change the password without logging the caller
    // out of the device they're using right now.
    return new ApiResponseDto(HttpStatus.OK, 'Password changed successfully');
  }

  async getMe(userId: number, tenantId: string): Promise<ApiResponseDto> {
    const user = await this.usersRepository.findByTenantAndId(
      tenantId,
      userId,
      true,
    );

    if (!user) {
      throw new BadRequestException('User not found');
    }

    const { password: _, ...result } = user;
    return new ApiResponseDto(
      HttpStatus.OK,
      'User details fetched successfully',
      result,
    );
  }

  async updateMe(
    userId: number,
    tenantId: string,
    updateMeDto: UpdateMeDto,
  ): Promise<ApiResponseDto> {
    const user = await this.usersRepository.findByTenantAndId(tenantId, userId);

    if (!user) throw new BadRequestException('User not found');

    // Self-service updates are gated per-tenant by `system_settings.user_profile.*`
    // (an admin may lock a field like NIC after verification) — admin updates via
    // UsersService bypass this filter entirely.
    const { allowedFields, blockedFields } =
      await this.settingsService.filterAllowedFields(
        tenantId,
        updateMeDto as Record<string, unknown>,
      );

    if (
      typeof allowedFields.email === 'string' &&
      allowedFields.email !== user.email
    ) {
      const emailExists = await this.usersRepository.findByEmail(
        tenantId,
        allowedFields.email,
      );
      if (emailExists) {
        throw new BadRequestException('Email already in use');
      }
    }

    Object.assign(user, allowedFields);
    await this.usersRepository.save(user);

    const { password: _, ...result } = user;
    return new ApiResponseDto(
      HttpStatus.OK,
      'User details updated successfully',
      {
        ...result,
        updateInfo: { blockedFields },
      },
    );
  }

  async register(
    registerDto: RegisterDto,
    tenantId: string,
  ): Promise<ApiResponseDto> {
    const { email, phone, NIC, password, gender, ...rest } = registerDto;

    if (email) {
      const emailExists = await this.usersRepository.findByEmail(
        tenantId,
        email,
      );
      if (emailExists) throw new BadRequestException('Email already in use');
    }

    const formattedPhone = formatPhoneNumber(phone);

    if (formattedPhone) {
      const phoneExists = await this.usersRepository.findByPhone(
        tenantId,
        formattedPhone,
      );
      if (phoneExists)
        throw new BadRequestException('Phone number already in use');
    }

    if (NIC) {
      const nicExists = await this.usersRepository.findByNIC(tenantId, NIC);
      if (nicExists) throw new BadRequestException('NIC already in use');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const studentRole = await this.rolesRepository.findByName(UserRole.STUDENT);

    if (!studentRole) {
      throw new BadRequestException(
        'Unable to register, please contact the administrator ERROR code 0001',
      );
    }

    const profileImg = rest.profileImg ?? DEFAULT_AVATARS[gender];

    const newUser = this.usersRepository.create({
      ...rest,
      email,
      phone: formattedPhone,
      NIC,
      password: hashedPassword,
      roleId: studentRole.id,
      tenantId: tenantId,
      status: UserStatus.PENDING,
      birthday: rest.birthday ?? DEFAULT_PROFILE_DEFAULTS.birthday,
      address: rest.address ?? DEFAULT_PROFILE_DEFAULTS.address,
      district: rest.district ?? DEFAULT_PROFILE_DEFAULTS.district,
      city: rest.city ?? DEFAULT_PROFILE_DEFAULTS.city,
      profileImg,
    });

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const savedUser = await this.usersRepository.save(
        newUser,
        queryRunner.manager,
      );

      // Generate and handle OTP
      const {
        success: smsSent,
        otpId,
        otp,
      } = await this.generateAndSendOtp(
        queryRunner.manager,
        savedUser.id,
        tenantId,
        savedUser.phone,
        SmsTemplates.OTP_VERIFICATION,
        OtpPurpose.REGISTRATION,
      );

      if (!smsSent && process.env.NODE_ENV === 'production') {
        throw new Error('Failed to send verification SMS');
      }

      await queryRunner.commitTransaction();

      const { password: _, ...result } = savedUser;
      return new ApiResponseDto(
        HttpStatus.CREATED,
        'User registered successfully. Please verify your OTP.',
        {
          ...result,
          otpId,
          ...(process.env.NODE_ENV !== 'production' ? { otp } : {}),
        },
      );
    } catch (error: any) {
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(
        error.message || 'Registration failed due to an internal error',
      );
    } finally {
      await queryRunner.release();
    }
  }

  // for registration only
  async resendOtp(
    resendOtpDto: ResendOtpDto,
    tenantId: string,
  ): Promise<ApiResponseDto> {
    const formattedPhone = formatPhoneNumber(resendOtpDto.phone);
    const user = await this.usersRepository.findByPhone(
      tenantId,
      formattedPhone,
    );

    if (!user) {
      throw new BadRequestException('User with this phone number not found');
    }

    if (user.status === UserStatus.EMAIL_VERIFIED) {
      throw new BadRequestException('User is already verified');
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const {
        success: smsSent,
        otpId,
        otp,
      } = await this.generateAndSendOtp(
        queryRunner.manager,
        user.id,
        tenantId,
        user.phone,
        SmsTemplates.OTP_VERIFICATION,
        OtpPurpose.REGISTRATION,
      );

      if (!smsSent && process.env.NODE_ENV === 'production') {
        throw new Error('Failed to send verification SMS');
      }
      await queryRunner.commitTransaction();
      return new ApiResponseDto(HttpStatus.OK, 'OTP resent successfully', {
        otpId,
        ...(process.env.NODE_ENV !== 'production' ? { otp } : {}),
      });
    } catch (error: any) {
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(error.message || 'Failed to resend OTP');
    } finally {
      await queryRunner.release();
    }
  }

  // for registration otp verification only
  async verifyOtp(
    verifyOtpDto: VerifyOtpDto,
    tenantId: string,
  ): Promise<ApiResponseDto> {
    const { phone, otp, otpId } = verifyOtpDto;
    const formattedPhone = formatPhoneNumber(phone);

    const userOtp = await this.userOtpRepository.findByIdAndTenant(
      tenantId,
      otpId,
    );

    if (!userOtp) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    // An OTP issued for password-reset must never verify a registration —
    // rejected without consuming it, so the OTP it actually belongs to can
    // still be used for its real purpose.
    if (userOtp.purpose && userOtp.purpose !== OtpPurpose.REGISTRATION) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    const user = await this.usersRepository.findByIdAndPhone(
      tenantId,
      userOtp.userId,
      formattedPhone,
    );
    if (!user) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    if (user.status === UserStatus.EMAIL_VERIFIED) {
      throw new BadRequestException('User is already verified');
    }

    if (new Date() > userOtp.expiresAt) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    const isValid = await bcrypt.compare(otp, userOtp.otpHash);
    if (!isValid) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    user.status = UserStatus.EMAIL_VERIFIED;
    await this.usersRepository.save(user);
    await this.userOtpRepository.deleteById(otpId);

    return new ApiResponseDto(HttpStatus.OK, 'OTP verified successfully');
  }

  async forgotPassword(
    forgotPasswordDto: ForgotPasswordDto,
    tenantId: string,
  ): Promise<ApiResponseDto> {
    const formattedPhone = formatPhoneNumber(forgotPasswordDto.phone);
    const user = await this.usersRepository.findByPhone(
      tenantId,
      formattedPhone,
    );

    // Never reveal whether a phone number belongs to an account: an unknown
    // or ineligible (blocked/deleted) phone gets the exact same 200 an
    // eligible one's SMS-delivery-failure path would produce.
    if (
      !user ||
      user.status === UserStatus.BLOCKED ||
      user.status === UserStatus.DELETED
    ) {
      return new ApiResponseDto(
        HttpStatus.OK,
        'If an eligible account exists, a password reset OTP has been sent',
      );
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const {
        success: smsSent,
        otpId,
        otp,
      } = await this.generateAndSendOtp(
        queryRunner.manager,
        user.id,
        tenantId,
        user.phone,
        SmsTemplates.PASSWORD_RESET,
        OtpPurpose.PASSWORD_RESET,
      );

      if (!smsSent && process.env.NODE_ENV === 'production') {
        throw new Error('Failed to send password reset SMS');
      }

      await queryRunner.commitTransaction();
      return new ApiResponseDto(
        HttpStatus.CREATED,
        'Password reset OTP sent successfully',
        {
          otpId,
          ...(process.env.NODE_ENV !== 'production' ? { otp } : {}),
        },
      );
    } catch (error: any) {
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(
        error.message || 'Failed to process forgot password request',
      );
    } finally {
      await queryRunner.release();
    }
  }

  async resetPassword(
    resetPasswordDto: ResetPasswordDto,
    tenantId: string,
  ): Promise<ApiResponseDto> {
    const { phone, otp, otpId, newPassword } = resetPasswordDto;
    const formattedPhone = formatPhoneNumber(phone);

    const userOtp = await this.userOtpRepository.findByIdAndTenant(
      tenantId,
      otpId,
    );

    if (!userOtp) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    // Symmetric to verifyOtp: a registration-purpose OTP must never apply a
    // password reset, and rejecting it here must not consume it.
    if (userOtp.purpose && userOtp.purpose !== OtpPurpose.PASSWORD_RESET) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    const user = await this.usersRepository.findByIdAndPhone(
      tenantId,
      userOtp.userId,
      formattedPhone,
    );
    if (!user) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    if (new Date() > userOtp.expiresAt) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    const isValid = await bcrypt.compare(otp, userOtp.otpHash);
    if (!isValid) {
      throw new BadRequestException(INVALID_OTP_MESSAGE);
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await this.usersRepository.save(user);
    await this.userOtpRepository.deleteById(otpId);

    return new ApiResponseDto(HttpStatus.OK, 'Password reset successfully');
  }

  private async generateAndSendOtp(
    manager: EntityManager,
    userId: number,
    tenantId: string,
    userPhone: string,
    templateFn: (
      siteName: string,
      otp: string,
      expireMinutes: number,
    ) => string,
    purpose: OtpPurpose,
  ): Promise<{ success: boolean; otpId: string; otp: string }> {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpHash = await bcrypt.hash(otp, 10);
    const expireMinutes = parseInt(process.env.OTP_EXPIRE_MINUTES || '10', 10);
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + expireMinutes);

    const userOtp = this.userOtpRepository.create({
      userId,
      otpHash,
      expiresAt,
      tenantId: tenantId,
      purpose,
    });
    const savedOtp = await this.userOtpRepository.save(userOtp, manager);

    const tenant = await this.tenantsService.findById(tenantId);
    const siteName = tenant ? tenant.name : 'our platform';

    const otpMessage = templateFn(siteName, otp, expireMinutes);
    const success = await this.smsService.sendSms(
      formatPhoneNumber(userPhone),
      otpMessage,
    );

    if (!success && process.env.NODE_ENV !== 'production') {
      this.logger.warn(
        `SMS delivery failed for otpId ${savedOtp.id}; continuing since NODE_ENV is not production.`,
      );
    }

    return { success, otpId: savedOtp.id, otp };
  }
}
