import {
  IsEmail,
  IsNotEmpty,
  IsString,
  IsOptional,
  MinLength,
  IsDateString,
  IsEnum,
} from 'class-validator';
import { District } from '../../users/enums/district.enum';
import { Gender } from '../../users/enums/gender.enum';

export class RegisterDto {
  @IsEmail({}, { message: 'Please provide a valid email address' })
  @IsNotEmpty({ message: 'Email is required' })
  email: string;

  @IsString()
  @IsNotEmpty({ message: 'Phone number is required' })
  phone: string;

  @IsString()
  @IsNotEmpty({ message: 'First name is required' })
  firstName: string;

  @IsString()
  @IsNotEmpty({ message: 'Last name is required' })
  lastName: string;

  @IsString()
  @IsNotEmpty({ message: 'NIC is required' })
  NIC: string;

  @IsString()
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(6, { message: 'Password must be at least 6 characters long' })
  password: string;

  @IsOptional()
  @IsDateString({}, { message: 'Birthday must be a valid date string' })
  birthday?: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsEnum(District, { message: 'Please provide a valid district' })
  district?: District;

  @IsOptional()
  @IsString()
  city?: string;

  @IsOptional()
  @IsString()
  profileImg?: string;

  @IsEnum(Gender, { message: 'Please provide a valid gender' })
  @IsNotEmpty({ message: 'Gender is required' })
  gender: Gender;
}
