import { IsNotEmpty, IsString, Length, IsUUID } from 'class-validator';

export class VerifyOtpDto {
  @IsString()
  @IsNotEmpty({ message: 'Phone number is required' })
  phone: string;

  @IsString()
  @IsNotEmpty({ message: 'OTP is required' })
  @Length(6, 6, { message: 'OTP must be exactly 6 digits long' })
  otp: string;

  @IsUUID()
  @IsNotEmpty({ message: 'OTP ID is required' })
  otpId: string;
}
