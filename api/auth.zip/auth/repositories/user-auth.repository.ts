import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserDetail } from '../../../database/entities/user.entity';
import { BaseRepository } from '../../../common/repositories/base.repository';

@Injectable()
export class UserAuthRepository extends BaseRepository<UserDetail> {
  constructor(
    @InjectRepository(UserDetail)
    repository: Repository<UserDetail>,
  ) {
    super(repository);
  }

  findByPhone(
    tenantId: string,
    phone: string,
    withRole = false,
  ): Promise<UserDetail | null> {
    return this.repository.findOne({
      where: { phone, tenantId: tenantId },
      relations: withRole ? { role: true } : undefined,
    });
  }

  findByEmail(tenantId: string, email: string): Promise<UserDetail | null> {
    return this.repository.findOneBy({ email, tenantId: tenantId });
  }

  findByNIC(tenantId: string, NIC: string): Promise<UserDetail | null> {
    return this.repository.findOneBy({ NIC, tenantId: tenantId });
  }

  findByTenantAndId(
    tenantId: string,
    id: number,
    withRole = false,
  ): Promise<UserDetail | null> {
    return this.repository.findOne({
      where: { id, tenantId: tenantId },
      relations: withRole ? { role: true } : undefined,
    });
  }

  findByIdAndPhone(
    tenantId: string,
    id: number,
    phone: string,
  ): Promise<UserDetail | null> {
    return this.repository.findOneBy({ id, phone, tenantId: tenantId });
  }
}
