import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Role } from '../../../database/entities/role.entity';
import { UserRole } from '../../roles/enums/user-role.enum';

@Injectable()
export class RoleAuthRepository {
  constructor(
    @InjectRepository(Role)
    private readonly repository: Repository<Role>,
  ) {}

  findByName(name: UserRole): Promise<Role | null> {
    return this.repository.findOneBy({ name });
  }
}
