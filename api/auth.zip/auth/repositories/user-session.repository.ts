import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, IsNull, LessThan, Repository } from 'typeorm';
import { UserSession } from '../../../database/entities/user-session.entity';

@Injectable()
export class UserSessionRepository {
  constructor(
    @InjectRepository(UserSession)
    private readonly repository: Repository<UserSession>,
  ) {}

  /** Builds an in-memory entity only — pair with `save()` to persist it. */
  create(data: Partial<UserSession>): UserSession {
    return this.repository.create(data);
  }

  save(entity: UserSession, manager?: EntityManager): Promise<UserSession> {
    return manager ? manager.save(entity) : this.repository.save(entity);
  }

  /** A session is "live" while it hasn't been revoked (logout/rotation/block). */
  findLiveById(id: number): Promise<UserSession | null> {
    return this.repository.findOne({
      where: { id, isActive: true, revokedAt: IsNull() },
    });
  }

  findByUserId(tenantId: string, userId: number): Promise<UserSession[]> {
    return this.repository.find({
      where: { tenantId, userId },
      order: { createdAt: 'DESC' },
    });
  }

  async revokeById(id: number, manager?: EntityManager): Promise<void> {
    const repo = manager ? manager.getRepository(UserSession) : this.repository;
    await repo.update({ id }, { revokedAt: new Date(), isActive: false });
  }

  /** Used when an admin blocks/archives a user — every live session for them dies at once. */
  async revokeAllForUser(
    tenantId: string,
    userId: number,
    manager?: EntityManager,
  ): Promise<void> {
    const repo = manager ? manager.getRepository(UserSession) : this.repository;
    await repo.update(
      { tenantId, userId, revokedAt: IsNull() },
      { revokedAt: new Date(), isActive: false },
    );
  }

  /** Maintenance cron: purge the login audit trail past its retention window. */
  async deleteOlderThan(before: Date): Promise<number> {
    const result = await this.repository.delete({
      createdAt: LessThan(before),
    });
    return result.affected ?? 0;
  }
}
