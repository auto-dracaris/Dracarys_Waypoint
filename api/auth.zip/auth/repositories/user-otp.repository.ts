import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { LessThan, Repository } from 'typeorm';
import { UserOtp } from '../../../database/entities/user-otp.entity';
import { BaseRepository } from '../../../common/repositories/base.repository';

@Injectable()
export class UserOtpRepository extends BaseRepository<UserOtp> {
  constructor(
    @InjectRepository(UserOtp)
    repository: Repository<UserOtp>,
  ) {
    super(repository);
  }

  findByIdAndTenant(tenantId: string, id: string): Promise<UserOtp | null> {
    return this.repository.findOne({ where: { id, tenantId } });
  }

  deleteById(id: string): Promise<unknown> {
    return this.repository.delete({ id });
  }

  /** Maintenance cron: reap abandoned OTPs past their own expiry. */
  async deleteExpired(before: Date): Promise<number> {
    const result = await this.repository.delete({
      expiresAt: LessThan(before),
    });
    return result.affected ?? 0;
  }
}
