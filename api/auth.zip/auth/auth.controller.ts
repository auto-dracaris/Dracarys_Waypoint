import {
  Controller,
  Post,
  Body,
  Put,
  Get,
  UseGuards,
  Req,
  Res,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import type { Response } from 'express';
import { AuthService } from './auth.service';
import { TenantId } from '../../common/decorators/tenant.decorator';
import { ApiResponseDto } from '../../common/dto/api-response.dto';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { UpdateMeDto } from './dto/update-me.dto';
import { ResendOtpDto } from './dto/resend-otp.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import * as crypto from 'crypto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { AuthenticatedUser } from '../../common/decorators/current-user.decorator';

@Controller('/api/auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(
    @Body() body: LoginDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.login(body, tenantId);
  }

  // to be moved to user module // RAMISHKA
  @UseGuards(JwtAuthGuard)
  @Get('me')
  async getMe(
    @Req() req: any,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.getMe(req.user.userId, tenantId);
  }

  @UseGuards(JwtAuthGuard)
  @Put('me')
  async updateMe(
    @Req() req: any,
    @Body() updateMeDto: UpdateMeDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.updateMe(req.user.userId, tenantId, updateMeDto);
  }

  @Post('register')
  async register(
    @Body() registerDto: RegisterDto,
    @TenantId() tenantId: crypto.UUID,
  ): Promise<ApiResponseDto> {
    return this.authService.register(registerDto, tenantId);
  }

  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  async verifyOtp(
    @Body() verifyOtpDto: VerifyOtpDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.verifyOtp(verifyOtpDto, tenantId);
  }

  @Post('resend-otp')
  async resendOtp(
    @Body() resendOtpDto: ResendOtpDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.resendOtp(resendOtpDto, tenantId);
  }

  // Not a static @HttpCode(): the response is deliberately 201 for an
  // eligible account and 200 for an unknown/ineligible one (the service
  // picks which), so the actual HTTP status has to be set per branch here
  // instead of relying on Nest's POST-defaults-to-201 behavior.
  @Post('forgot-password')
  async forgotPassword(
    @Body() forgotPasswordDto: ForgotPasswordDto,
    @TenantId() tenantId: string,
    @Res({ passthrough: true }) res: Response,
  ): Promise<ApiResponseDto> {
    const result = await this.authService.forgotPassword(
      forgotPasswordDto,
      tenantId,
    );
    res.status(result.statusCode);
    return result;
  }

  @Put('reset-password')
  async resetPassword(
    @Body() resetPasswordDto: ResetPasswordDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.resetPassword(resetPasswordDto, tenantId);
  }

  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  async refresh(
    @Body() refreshTokenDto: RefreshTokenDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.refresh(refreshTokenDto, tenantId);
  }

  @UseGuards(JwtAuthGuard)
  @Post('logout')
  @HttpCode(HttpStatus.OK)
  async logout(
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<ApiResponseDto> {
    return this.authService.logout(user.sessionId);
  }

  @UseGuards(JwtAuthGuard)
  @Put('change-password')
  async changePassword(
    @CurrentUser() user: AuthenticatedUser,
    @Body() changePasswordDto: ChangePasswordDto,
    @TenantId() tenantId: string,
  ): Promise<ApiResponseDto> {
    return this.authService.changePassword(
      user.userId,
      tenantId,
      changePasswordDto,
    );
  }
}
